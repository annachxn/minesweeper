Name: Anna Chen
Section: 24923
UFL email: chenanna@ufl.edu
System: Windows 11
Compiler: g++ (x86_64-win32-sjlj-rev0, Built by MinGW-W64 project) 8.1.0
SFML version: SFML-2.5.1-windows-gcc-7.3.0-mingw-64-bit
IDE: CLion
Other notes: 